public class CoffeeResStub {

    public void refillMilk(int i){

    }

    public void refillBeans(int i){

    }

    public void refillWater(int i){

    }

    public void refillChoco(int i){

    }

    public boolean useMilk(){
        return true;
    }

    public boolean useBeans(){
        return true;
    }

    public boolean useWater(){
        return true;
    }

    public boolean useChoco(){
        return true;
    }

}
