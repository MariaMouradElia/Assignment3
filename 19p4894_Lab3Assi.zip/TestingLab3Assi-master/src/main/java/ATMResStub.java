public class ATMResStub {

    public void fill(int i){

    }

    public boolean withdraw(){
        return true;
    }

}
