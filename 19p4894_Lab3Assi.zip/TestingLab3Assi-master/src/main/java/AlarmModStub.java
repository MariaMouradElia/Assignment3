public class AlarmModStub {

    public boolean setA(){
        return true;
    }

    public boolean unsetA(){
        return true;
    }

    public boolean checkA(){
        return true;
    }

}
